"""
spatial_graph_builder.py

Phase 3: Build the final LLM-friendly Spatial Graph JSON from a TFExample record.

Inputs (confirmed present in TFExample conversion):
- Ego: state/*
- Roadgraph: roadgraph_samples/{xyz,valid,type,id,dir,speed_limit}
- Traffic lights: traffic_light_state/{current,past,future}/*
- Route prior: path_samples/* (optional but present in record0)

Outputs:
- Dict JSON with:
  meta, nodes, edges

We DO NOT assume:
- lane successor/predecessor topology (not in TFExample)
- explicit traffic-light-to-lane association (not in TFExample)
So TL relevance is heuristic: "ahead + small |y_local| + within radius".
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from spatial_graph.utils.tfexample_io import (
    EgoState,
    RoadgraphSamples,
    TrafficLightSet,
    PathSamples,
    get_ego_state,
    get_roadgraph_samples,
    get_traffic_lights_current,
    get_traffic_lights_time_major,
    get_path_samples,
)

from spatial_graph.utils.geometry import ego_frame

from spatial_graph.modules.polyline_grouper import (
    PolylineGrouperConfig,
    MapFeature,
    build_map_features_from_roadgraph,
)

from spatial_graph.modules.route_monitor import (
    RouteMonitorConfig,
    RouteNode,
    EgoRouteEdge,
    build_route_node_and_edge,
    route_node_to_dict,
    ego_route_edge_to_dict,
)


# -------------------------
# Config
# -------------------------
@dataclass(frozen=True)
class SpatialGraphConfig:
    poly_cfg: PolylineGrouperConfig = PolylineGrouperConfig()
    route_cfg: RouteMonitorConfig = RouteMonitorConfig()

    # Traffic-light selection
    tl_radius_m: float = 80.0
    tl_topk: int = 20

    # TL relevance heuristic (since we don't have TL↔lane association)
    tl_relevance_y_thresh_m: float = 6.0  # "near centerline" heuristic
    tl_relevance_min_x_m: float = 0.0     # only consider ahead by default

    # edge bucketing
    dist_very_close_m: float = 5.0
    dist_close_m: float = 15.0
    dist_medium_m: float = 30.0

    # speed limit overspeed margin (m/s)
    overspeed_margin_mps: float = 0.5


# -------------------------
# Helpers
# -------------------------
def _dist_bucket(d: float, cfg: SpatialGraphConfig) -> str:
    if d < cfg.dist_very_close_m:
        return "very_close"
    if d < cfg.dist_close_m:
        return "close"
    if d < cfg.dist_medium_m:
        return "medium"
    return "far"


def _node(node_id: str, node_type: str, attrs: Dict[str, Any]) -> Dict[str, Any]:
    return {"id": node_id, "type": node_type, "attrs": attrs}


def _edge(src: str, dst: str, edge_type: str, attrs: Dict[str, Any]) -> Dict[str, Any]:
    return {"src": src, "dst": dst, "type": edge_type, "attrs": attrs}


def _safe_float(x: Any) -> Optional[float]:
    try:
        return float(x)
    except Exception:
        return None


# -------------------------
# Traffic light feature extraction
# -------------------------
def _compute_tl_future_features(
    tl_index: int,
    cur_state: Optional[int],
    tl_future: Dict[str, np.ndarray],
) -> Dict[str, Any]:
    """
    Compute future-change features WITHOUT assuming enum meaning.
    We report:
      - future_unique_states_valid
      - time_to_change_steps (first step where state != cur_state)
      - time_to_first_seen_state_steps (for each unique state)
    """
    if "state" not in tl_future or "valid" not in tl_future:
        return {}

    state = tl_future["state"]  # (T, L)
    valid = tl_future["valid"]  # (T, L) int/float -> we'll treat >0 as valid

    if tl_index < 0 or tl_index >= state.shape[1]:
        return {}

    s = state[:, tl_index].astype(np.int64)
    v = valid[:, tl_index].astype(np.int64) > 0

    s_valid = s[v]
    if s_valid.size == 0:
        return {}

    uniq = np.unique(s_valid).tolist()

    # time to change from current
    time_to_change = None
    if cur_state is not None:
        diff = (s != int(cur_state)) & v
        where = np.where(diff)[0]
        if where.size > 0:
            time_to_change = int(where[0])

    # time to first occurrence of each state (valid only)
    first_seen: Dict[int, int] = {}
    for st in uniq:
        where = np.where((s == st) & v)[0]
        if where.size > 0:
            first_seen[int(st)] = int(where[0])

    return {
        "future_unique_states_valid": uniq,
        "time_to_change_steps": time_to_change,
        "time_to_first_seen_state_steps": first_seen,
        "future_horizon_steps": int(state.shape[0]),
    }


# -------------------------
# Main builder
# -------------------------
def build_spatial_graph_from_example(
    example: Any,  # tf.train.Example
    record_index: Optional[int] = None,
    cfg: SpatialGraphConfig = SpatialGraphConfig(),
) -> Dict[str, Any]:
    """
    Build the spatial graph JSON from one TFExample record.

    Returns:
      dict with keys: meta, nodes, edges
    """
    features = example.features.feature

    # ---- Extract core data ----
    ego: EgoState = get_ego_state(features)
    rg: RoadgraphSamples = get_roadgraph_samples(features)
    tl_cur: TrafficLightSet = get_traffic_lights_current(features)
    path: Optional[PathSamples] = get_path_samples(features)

    # Time-major TL sequences for future/past (used for change features)
    num_lights = int(tl_cur.valid.size)
    tl_future = get_traffic_lights_time_major(features, "future", num_lights=num_lights)
    tl_past = get_traffic_lights_time_major(features, "past", num_lights=num_lights)

    # ---- Phase 1: map features (polylines) ----
    map_features: List[MapFeature] = build_map_features_from_roadgraph(rg=rg, ego=ego, cfg=cfg.poly_cfg)

    # ---- Phase 2: route ----
    route_pack = build_route_node_and_edge(ego=ego, path=path, cfg=cfg.route_cfg)
    route_node: Optional[RouteNode] = None
    route_edge: Optional[EgoRouteEdge] = None
    if route_pack is not None:
        route_node, route_edge = route_pack

    # ---- Build nodes ----
    nodes: List[Dict[str, Any]] = []
    edges: List[Dict[str, Any]] = []

    ego_id = "ego"
    nodes.append(
        _node(
            node_id=ego_id,
            node_type="EGO",
            attrs={
                "x": float(ego.x),
                "y": float(ego.y),
                "yaw": float(ego.yaw),
                "speed_mps": float(ego.speed),
                "speed_source": ego.speed_source,
            },
        )
    )

    # Map feature nodes + ego->map edges
    for mf in map_features:
        nid = f"map_{mf.polyline_id}"
        nodes.append(
            _node(
                node_id=nid,
                node_type="MAP_FEATURE",
                attrs={
                    "polyline_id": int(mf.polyline_id),
                    "type_mode": mf.type_mode,
                    "num_points": int(mf.num_points),
                    "centroid_xy": list(mf.centroid_xy),
                    "bbox_xy_min": list(mf.bbox_xy_min),
                    "bbox_xy_max": list(mf.bbox_xy_max),
                    "speed_limit_mps": mf.speed_limit_mps,
                    "heading_alignment_cos": mf.heading_alignment_cos,
                    # keep samples small (debug/heuristics)
                    "sample_points_xy": mf.sample_points_xy,
                },
            )
        )

        overspeeding = None
        if mf.speed_limit_mps is not None:
            overspeeding = bool(ego.speed > (mf.speed_limit_mps + cfg.overspeed_margin_mps))

        edges.append(
            _edge(
                src=ego_id,
                dst=nid,
                edge_type="EGO_TO_MAP",
                attrs={
                    "closest_dist_m": float(mf.closest_dist_m),
                    "closest_world_xy": list(mf.closest_world_xy),
                    "x_local_m": float(mf.closest_x_local_m),
                    "y_local_m": float(mf.closest_y_local_m),
                    "distance_bucket": _dist_bucket(float(mf.closest_dist_m), cfg),
                    "ahead": bool(mf.closest_x_local_m > 0.0),
                    "left": bool(mf.closest_y_local_m > 0.0),
                    "overspeeding": overspeeding,
                },
            )
        )

    # Traffic light nodes + ego->TL edges
    tl_valid_idx = np.where(tl_cur.valid.astype(bool))[0]
    if tl_valid_idx.size > 0:
        tl_x = tl_cur.x[tl_valid_idx]
        tl_y = tl_cur.y[tl_valid_idx]

        dx = tl_x - float(ego.x)
        dy = tl_y - float(ego.y)
        dist = np.sqrt(dx * dx + dy * dy)

        # radius filter
        in_rad = dist <= float(cfg.tl_radius_m)
        idx2 = tl_valid_idx[in_rad]
        dist2 = dist[in_rad]
        dx2 = dx[in_rad]
        dy2 = dy[in_rad]

        # ego frame for relevance
        x_local, y_local = ego_frame(dx2.astype(np.float32), dy2.astype(np.float32), float(ego.yaw))

        # top-k closest
        order = np.argsort(dist2)[: min(int(cfg.tl_topk), int(idx2.size))]
        idx_pick = idx2[order]
        dist_pick = dist2[order]
        xloc_pick = x_local[order]
        yloc_pick = y_local[order]

        for j, tl_idx in enumerate(idx_pick):
            tl_idx = int(tl_idx)

            tid = int(tl_cur.tl_id[tl_idx]) if tl_cur.tl_id is not None else tl_idx
            nid = f"tl_{tid}"

            cur_state = int(tl_cur.state[tl_idx]) if tl_cur.state is not None else None

            # Node
            nodes.append(
                _node(
                    node_id=nid,
                    node_type="TRAFFIC_LIGHT",
                    attrs={
                        "tl_id": int(tid),
                        "x": float(tl_cur.x[tl_idx]),
                        "y": float(tl_cur.y[tl_idx]),
                        "state_now": cur_state,
                    },
                )
            )

            # Heuristic relevance
            ahead = bool(xloc_pick[j] >= cfg.tl_relevance_min_x_m)
            centered = bool(abs(float(yloc_pick[j])) <= cfg.tl_relevance_y_thresh_m)
            likely_controls_ego = bool(ahead and centered)

            fut_feats = _compute_tl_future_features(
                tl_index=tl_idx,
                cur_state=cur_state,
                tl_future=tl_future,
            )

            edges.append(
                _edge(
                    src=ego_id,
                    dst=nid,
                    edge_type="EGO_TO_TL",
                    attrs={
                        "dist_m": float(dist_pick[j]),
                        "x_local_m": float(xloc_pick[j]),
                        "y_local_m": float(yloc_pick[j]),
                        "ahead": ahead,
                        "likely_controls_ego": likely_controls_ego,
                        "distance_bucket": _dist_bucket(float(dist_pick[j]), cfg),
                        **fut_feats,
                    },
                )
            )

    # Route node + ego->route edge
    if route_node is not None and route_edge is not None:
        rid = int(route_node.route_id)
        route_id = f"route_{rid}"
        nodes.append(_node(node_id=route_id, node_type="ROUTE", attrs=route_node_to_dict(route_node)))
        edges.append(
            _edge(
                src=ego_id,
                dst=route_id,
                edge_type="EGO_TO_ROUTE",
                attrs=ego_route_edge_to_dict(route_edge),
            )
        )

    meta = {
        "record_index": int(record_index) if record_index is not None else None,
        "num_map_features": int(len(map_features)),
        "num_nodes": int(len(nodes)),
        "num_edges": int(len(edges)),
        "limits": {
            "max_polylines": int(cfg.poly_cfg.max_polylines),
            "tl_topk": int(cfg.tl_topk),
        },
        "notes": {
            "no_lane_topology_in_tfexample": True,
            "no_tl_lane_control_in_tfexample": True,
            "tl_relevance_is_heuristic": True,
        },
    }

    return {"meta": meta, "nodes": nodes, "edges": edges}
